var board = ["Name","Phone","Wechat","Email","Date","Time","FromCity","ToCity","NoOfPpl","Price","Type","TextArea"];
