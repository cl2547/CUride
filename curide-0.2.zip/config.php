<?php

global $DEBUG;
$DEBUG = False;

$heading = "CU Ride Information Exchange [Still Testing]";

// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "board";
// $datatablename = "board";
// $infotablename = "user_info";
// $rootpath = "/myfiles/curide/src/";


$servername = "localhost";
$username = "id6885213_sx243";
$password = "asdf1234";
$dbname = "id6885213_curidedb";
$datatablename = "board";
$infotablename = "user_info";
$rootpath = "/CURIDE-src/"


/* modified 2018/09/03 - US EST */

?>