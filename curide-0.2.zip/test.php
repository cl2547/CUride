<?php

error_reporting( E_ALL ); 

echo "hello";

?>


